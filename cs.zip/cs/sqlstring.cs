<script runat=server>
const string m_sDataSource = ";data source=localhost;";
const string m_sSecurityString = "User id=eznz;Password=9seqxtf7;Integrated Security=false;";
//const string m_sSecurityString = "Integrated Security=SSPI;";
const string m_emailAlertTo = "alter1@eznz.com";
const string m_sCompanyName = "superdeal";	//site identifer, used for cache, sql db name etc, highest priority
</script>
